﻿using SalesAutomation.Views;
using System;

namespace SalesAutomation
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuList list = new MenuList();
            list.Menu();
        }
    }
}
